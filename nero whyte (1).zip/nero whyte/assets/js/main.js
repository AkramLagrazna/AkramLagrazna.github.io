/**
 * Custom JS
 **/

(function() {
	// All variables
	var menuIcon = document.querySelectorAll(".menu-icon"),
		nav = document.getElementById("side-menu"),
		closeIcon = document.querySelector(".menu-close"),
		headerTop = document.querySelector(".header-top"),
		style = document.createElement("style"),
		blogSection = document.querySelector("#blog-section"),
		blogBtn = document.querySelectorAll(".blog-btn"),
		blogItems = document.querySelectorAll(".blog-items"),
		blogArrowUp = document.querySelector("#blog-section .arrow-up"),
		blogArrowDown = document.querySelector("#blog-section .arrow-down"),
		singleArrowUp = document.querySelector("#single-blog .arrow-up"),
		singleArrowDown = document.querySelector("#single-blog .arrow-down"),
		blogContent = document.querySelectorAll(".single-blog h4,.single-blog p,.single-blog img");
		workItem = document.querySelectorAll('.work-items');
		workBtn = document.querySelectorAll('.works .work-btns ul li');
		
	i = 0;

	// Add custom styles
	document.head.insertAdjacentElement("beforeend", style);

	// Show side navigation
	menuIcon.forEach(function(icon) {
		icon.addEventListener("click", function() {
			nav.classList.toggle("menu-open");
			nav.classList.contains("menu-open") ? headerTop.classList.add("heading-new-style") : headerTop.classList.remove("heading-new-style");
		});
	});

	// Hide side navigation
	closeIcon.addEventListener("click", function() {
		nav.classList.remove("menu-open");
		headerTop.classList.remove("heading-new-style");
	});

	// Toggle Blog Section
	blogBtn.forEach(function(btn) {
		btn.addEventListener("click", function() {
			blogSection.classList.toggle("open-blog");
			if (blogSection.classList.contains("open-blog")) {
				style.innerHTML = `
				header.header-top nav a {color: #fff;}
				header.header-top nav a:hover {color: #33e980;}
				header.header-top .menu-icon {color: #fff;}
				`;
				if (document.querySelector(".contact-side") && window.innerWidth <= 767) {
					document.querySelector(".contact-side").style.display = "none";
				}
			} else {
				style.innerHTML = `
					header.header-top nav a {color: #000;}
					header.header-top .menu-icon {color: #000;}
				`;
				if (document.querySelector(".contact-side") && window.innerWidth <= 767) {
					document.querySelector(".contact-side").style.display = "flex";
				}
			}
		});
	});

	// Blog up btn
	blogArrowUp.addEventListener("click", function() {
		i++;
		if (i == blogItems.length) {
			i = 0;
		}
		blogItems.forEach(function(item) {
			item.style.display = "none";
		});
		blogItems[i].style.display = "block";
	});

	// Blog down btn
	blogArrowDown.addEventListener("click", function() {
		i--;
		if (i < 0) {
			i = blogItems.length - 1;
		}
		blogItems.forEach(function(item) {
			item.style.display = "none";
		});
		blogItems[i].style.display = "block";
	});

	// Single Blog Arrowos
	if (singleArrowDown) {
		singleArrowDown.addEventListener("click", function() {
			blogContent.forEach(function(item) {
				item.style.transform = "translateY(-200px)";
			});
		});
	}

	// Single Blog Arrowos
	if (singleArrowUp) {
		singleArrowUp.addEventListener("click", function() {
			blogContent.forEach(function(item) {
				item.style.transform = "translateY(0px)";
			});
		});
	}

	// Portfolios

	if(workItem.length > 0) {
		workBtn.forEach(function(btn,index) {
			btn.addEventListener('click',function() {
				workItem.forEach(function(item) {
					item.style.display = 'none'
					workBtn.forEach(function(btn){
						btn.querySelector('a').style.color = '#fff';
					})
				});
				this.querySelector('a').style.color = '#33e980';
				workItem[index].style.display = 'block';
			});
		});
	}

	// Magnifiq popup
	if ($(".work-popup").length > 0) {
		$(".work-popup").magnificPopup({
			type: "image",
			gallery: {
				enabled: true
			}
		});
	}


})();
